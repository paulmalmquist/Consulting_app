# Floyorker Merch Pipeline — Setup & Usage

## One-time setup (5 min)

```bash
# 1. Install Python deps
pip install requests python-dotenv Pillow

# 2. Install potrace for best vectorization
brew install potrace           # macOS
sudo apt install potrace       # Ubuntu

# 3. Copy env file and fill in your keys
cp tools/.env.example tools/.env
```

Open `tools/.env` and fill in:
- **PRINTFUL_API_KEY** → Printful Dashboard → Store → API → Generate Token
- **PRINTFUL_STORE_ID** → Printful Dashboard → Store Settings → Store ID
- **SHOPIFY_STORE** → `yourstore.myshopify.com`
- **SHOPIFY_ADMIN_TOKEN** → Shopify Admin → Settings → Apps → Develop apps → create app with `write_products` scope
- **FLOYORKER_REPO_PATH** → absolute path to this repo on your machine

---

## Workflow

### Option A: Use the approval app (recommended)
1. Open `tools/design_approval.html` in your browser
2. Drag in your design (PNG or SVG)
3. Fill in title, type, price
4. Click **Approve & generate command**
5. Copy the generated command → paste into Cowork

### Option B: Tell Cowork directly
Say: *"Push this design"* and hand Cowork the file path + product details.
Cowork reads `COWORK_INSTRUCTIONS.md` and knows exactly what to do.

### Option C: Run manually
```bash
python tools/floyorker_pipeline.py \
  --svg designs/mydesign.svg \
  --title "My Design" \
  --product-type tshirt \
  --price 29.99
```

---

## Product types
| Type    | Product                 | Price range |
|---------|-------------------------|-------------|
| tshirt  | Bella+Canvas Unisex Tee | $28–$35     |
| hoodie  | Gildan Heavy Blend      | $45–$55     |
| poster  | Enhanced Matte Poster   | $18–$30     |
| sticker | Kiss-Cut Stickers       | $4–$8       |
| hat     | Yupoong Dad Hat         | $25–$35     |

---

## What gets created automatically
- ✅ Printful sync product with all size/color variants
- ✅ Shopify product (DRAFT — you publish when ready)
- ✅ `data/products/[handle].json` in this repo
- ✅ `data/products_index.json` updated

## To publish on Shopify
After reviewing the draft in Shopify Admin, tell Cowork:
> "Publish [product title] on Shopify"

Or do it manually in your Shopify Admin.

---

## File structure
```
floyorker/
├── designs/              ← drop your raw designs here
├── data/
│   ├── products/         ← auto-written by pipeline
│   └── products_index.json
├── tools/
│   ├── floyorker_pipeline.py
│   ├── png_to_vector.py
│   ├── design_approval.html
│   ├── .env              ← YOUR SECRETS (never commit)
│   └── .env.example
└── COWORK_INSTRUCTIONS.md
```
