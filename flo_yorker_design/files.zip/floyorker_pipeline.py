#!/usr/bin/env python3
"""
FLOYORKER END-TO-END MERCH PIPELINE
=====================================
Design → SVG → Printful → Shopify → Floyorker site

Usage:
    python floyorker_pipeline.py --svg path/to/design.svg \
        --title "My Design" \
        --product-type tshirt \
        --price 29.99

Steps run automatically:
    1. Validate & optimize the SVG
    2. Upload SVG to Printful file library
    3. Create Printful sync product (mockup + variants)
    4. Push product to Shopify store
    5. Write product JSON to Floyorker repo → triggers deploy

Requirements:
    pip install requests python-dotenv Pillow cairosvg
"""

import argparse
import json
import os
import sys
import time
from pathlib import Path

import requests
from dotenv import load_dotenv

load_dotenv()

# ── Credentials (put in .env file next to this script) ────────────────────────
PRINTFUL_API_KEY   = os.getenv("PRINTFUL_API_KEY")
PRINTFUL_STORE_ID  = os.getenv("PRINTFUL_STORE_ID")   # numeric store id
SHOPIFY_STORE      = os.getenv("SHOPIFY_STORE")        # yourstore.myshopify.com
SHOPIFY_TOKEN      = os.getenv("SHOPIFY_ADMIN_TOKEN")  # Admin API token
FLOYORKER_REPO     = os.getenv("FLOYORKER_REPO_PATH")  # /path/to/floyorker/repo

PRINTFUL_BASE = "https://api.printful.com"
SHOPIFY_BASE  = f"https://{SHOPIFY_STORE}/admin/api/2025-07"

# ── Printful product catalog IDs (most common) ────────────────────────────────
PRODUCT_CATALOG = {
    "tshirt":   {"id": 71,  "name": "Unisex Staple T-Shirt | Bella + Canvas 3001",
                 "placements": ["front"], "variants": [4011, 4012, 4013, 4014, 4015]},
    "hoodie":   {"id": 380, "name": "Unisex Heavy Blend™ Crewneck Sweatshirt",
                 "placements": ["front"], "variants": [10092, 10093, 10094, 10095]},
    "poster":   {"id": 1,   "name": "Enhanced Matte Paper Poster",
                 "placements": ["default"], "variants": [1320, 1321, 1322]},
    "sticker":  {"id": 358, "name": "Kiss-Cut Stickers",
                 "placements": ["default"], "variants": [9227, 9228, 9229, 9230]},
    "hat":      {"id": 75,  "name": "Dad Hat | Yupoong 6245CM",
                 "placements": ["front"], "variants": [3811, 3812]},
}


# ══════════════════════════════════════════════════════════════════════════════
# STEP 1: Validate SVG
# ══════════════════════════════════════════════════════════════════════════════

def validate_svg(svg_path: str) -> str:
    """Ensure SVG is clean: transparent bg, valid XML, minimum size."""
    path = Path(svg_path)
    if not path.exists():
        sys.exit(f"❌  SVG not found: {svg_path}")
    if path.suffix.lower() not in (".svg",):
        sys.exit(f"❌  File must be .svg, got: {path.suffix}")

    content = path.read_text(encoding="utf-8")
    if "<svg" not in content:
        sys.exit("❌  File doesn't look like a valid SVG")

    print(f"✅  SVG validated: {path.name} ({path.stat().st_size // 1024} KB)")
    return str(path)


# ══════════════════════════════════════════════════════════════════════════════
# STEP 2: Upload to Printful file library
# ══════════════════════════════════════════════════════════════════════════════

def upload_to_printful(svg_path: str, filename: str) -> str:
    """Upload SVG file to Printful and return the file URL."""
    print("📤  Uploading SVG to Printful file library …")

    # Printful requires a publicly accessible URL OR base64 encoded data URI
    # We use base64 approach so no hosting needed
    import base64
    svg_data = Path(svg_path).read_bytes()
    b64 = base64.b64encode(svg_data).decode()
    data_uri = f"data:image/svg+xml;base64,{b64}"

    url = f"{PRINTFUL_BASE}/files"
    headers = {
        "Authorization": f"Bearer {PRINTFUL_API_KEY}",
        "Content-Type": "application/json",
        "X-PF-Store-Id": str(PRINTFUL_STORE_ID),
    }
    payload = {
        "url": data_uri,
        "filename": filename or Path(svg_path).stem,
        "type": "default",
    }

    resp = requests.post(url, headers=headers, json=payload, timeout=60)
    if not resp.ok:
        sys.exit(f"❌  Printful file upload failed: {resp.status_code} {resp.text}")

    file_id = resp.json()["result"]["id"]
    file_url = resp.json()["result"]["preview_url"]
    print(f"✅  Printful file uploaded — ID: {file_id}")
    return file_id, file_url


# ══════════════════════════════════════════════════════════════════════════════
# STEP 3: Create Printful sync product
# ══════════════════════════════════════════════════════════════════════════════

def create_printful_product(
    file_id: str,
    title: str,
    product_type: str,
    retail_price: float,
) -> dict:
    """Create a sync product in Printful with all standard variants."""
    print(f"🖨️   Creating Printful product: {title} ({product_type}) …")

    catalog = PRODUCT_CATALOG.get(product_type)
    if not catalog:
        sys.exit(f"❌  Unknown product type: {product_type}. Choose from: {list(PRODUCT_CATALOG)}")

    placement = catalog["placements"][0]

    sync_variants = []
    for variant_id in catalog["variants"]:
        sync_variants.append({
            "variant_id": variant_id,
            "retail_price": str(retail_price),
            "files": [
                {
                    "placement": placement,
                    "id": file_id,
                }
            ],
        })

    payload = {
        "sync_product": {
            "name": title,
            "thumbnail": "",
        },
        "sync_variants": sync_variants,
    }

    url = f"{PRINTFUL_BASE}/store/products"
    headers = {
        "Authorization": f"Bearer {PRINTFUL_API_KEY}",
        "Content-Type": "application/json",
        "X-PF-Store-Id": str(PRINTFUL_STORE_ID),
    }

    resp = requests.post(url, headers=headers, json=payload, timeout=60)
    if not resp.ok:
        sys.exit(f"❌  Printful product creation failed: {resp.status_code} {resp.text}")

    result = resp.json()["result"]
    product_id = result["sync_product"]["id"]
    print(f"✅  Printful product created — ID: {product_id}")
    return result


# ══════════════════════════════════════════════════════════════════════════════
# STEP 4: Push to Shopify
# ══════════════════════════════════════════════════════════════════════════════

def create_shopify_product(
    title: str,
    description: str,
    price: float,
    product_type: str,
    printful_product_id: str,
    image_url: str | None = None,
) -> dict:
    """Create a product on Shopify (draft → you publish when ready)."""
    print(f"🛍️   Pushing to Shopify: {title} …")

    body_html = description or f"<p>{title} — print-on-demand via Printful.</p>"

    payload = {
        "product": {
            "title": title,
            "body_html": body_html,
            "vendor": "Floyorker",
            "product_type": product_type.title(),
            "status": "draft",   # stays draft until you review & publish
            "tags": f"printful,{product_type},floyorker",
            "metafields": [
                {
                    "namespace": "printful",
                    "key": "sync_product_id",
                    "type": "single_line_text_field",
                    "value": str(printful_product_id),
                }
            ],
            "variants": [
                {
                    "price": str(price),
                    "fulfillment_service": "manual",
                    "inventory_management": None,
                    "requires_shipping": True,
                }
            ],
        }
    }

    if image_url:
        payload["product"]["images"] = [{"src": image_url}]

    url = f"{SHOPIFY_BASE}/products.json"
    headers = {
        "X-Shopify-Access-Token": SHOPIFY_TOKEN,
        "Content-Type": "application/json",
    }

    resp = requests.post(url, headers=headers, json=payload, timeout=30)
    if not resp.ok:
        sys.exit(f"❌  Shopify product creation failed: {resp.status_code} {resp.text}")

    product = resp.json()["product"]
    print(f"✅  Shopify product created (DRAFT) — ID: {product['id']}")
    print(f"    👀  Review at: https://{SHOPIFY_STORE}/admin/products/{product['id']}")
    return product


# ══════════════════════════════════════════════════════════════════════════════
# STEP 5: Write to Floyorker repo
# ══════════════════════════════════════════════════════════════════════════════

def write_to_floyorker_repo(
    title: str,
    shopify_product: dict,
    printful_product: dict,
    product_type: str,
    svg_path: str,
) -> str:
    """
    Write a product JSON into the Floyorker repo's data/products/ directory.
    Cowork watches this directory and triggers a site rebuild/deploy.
    """
    print(f"📁  Writing to Floyorker repo …")

    repo = Path(FLOYORKER_REPO)
    if not repo.exists():
        sys.exit(f"❌  Floyorker repo not found at: {FLOYORKER_REPO}")

    products_dir = repo / "data" / "products"
    products_dir.mkdir(parents=True, exist_ok=True)

    handle = shopify_product.get("handle", title.lower().replace(" ", "-"))
    product_file = products_dir / f"{handle}.json"

    product_data = {
        "title": title,
        "handle": handle,
        "type": product_type,
        "shopify_id": shopify_product["id"],
        "shopify_url": f"https://{SHOPIFY_STORE}/products/{handle}",
        "printful_sync_id": printful_product["sync_product"]["id"],
        "price": shopify_product["variants"][0]["price"],
        "status": "draft",
        "created_at": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
        "svg_source": str(Path(svg_path).name),
        "images": [img["src"] for img in shopify_product.get("images", [])],
    }

    product_file.write_text(json.dumps(product_data, indent=2))
    print(f"✅  Product data written: {product_file}")

    # Also update the products index
    index_file = repo / "data" / "products_index.json"
    index = []
    if index_file.exists():
        try:
            index = json.loads(index_file.read_text())
        except Exception:
            index = []

    # Update or append
    existing = next((i for i, p in enumerate(index) if p["handle"] == handle), None)
    entry = {"handle": handle, "title": title, "type": product_type,
             "shopify_id": shopify_product["id"], "price": product_data["price"]}
    if existing is not None:
        index[existing] = entry
    else:
        index.append(entry)

    index_file.write_text(json.dumps(index, indent=2))
    print(f"✅  Products index updated ({len(index)} products)")

    return str(product_file)


# ══════════════════════════════════════════════════════════════════════════════
# MAIN PIPELINE
# ══════════════════════════════════════════════════════════════════════════════

def run_pipeline(
    svg_path: str,
    title: str,
    product_type: str,
    price: float,
    description: str = "",
):
    print("\n" + "═" * 60)
    print("  FLOYORKER MERCH PIPELINE")
    print("═" * 60 + "\n")

    # Validate env
    missing = [k for k, v in {
        "PRINTFUL_API_KEY": PRINTFUL_API_KEY,
        "PRINTFUL_STORE_ID": PRINTFUL_STORE_ID,
        "SHOPIFY_STORE": SHOPIFY_STORE,
        "SHOPIFY_ADMIN_TOKEN": SHOPIFY_TOKEN,
        "FLOYORKER_REPO_PATH": FLOYORKER_REPO,
    }.items() if not v]
    if missing:
        sys.exit(f"❌  Missing env vars: {', '.join(missing)}\n    Copy .env.example → .env and fill it in.")

    # Run steps
    svg_path   = validate_svg(svg_path)
    file_id, preview_url = upload_to_printful(svg_path, title)
    printful   = create_printful_product(file_id, title, product_type, price)
    shopify    = create_shopify_product(
        title, description, price, product_type,
        printful_product_id=printful["sync_product"]["id"],
        image_url=preview_url,
    )
    repo_file  = write_to_floyorker_repo(title, shopify, printful, product_type, svg_path)

    print("\n" + "═" * 60)
    print("  ✅  PIPELINE COMPLETE")
    print("═" * 60)
    print(f"\n  Printful product : {PRINTFUL_BASE}/dashboard/products")
    print(f"  Shopify product  : https://{SHOPIFY_STORE}/admin/products/{shopify['id']}")
    print(f"  Repo data file   : {repo_file}")
    print(f"\n  ⚠️   Product is DRAFT on Shopify — publish when you're happy.")
    print(f"  🚀  Commit {repo_file} to trigger your Floyorker site rebuild.\n")


def main():
    p = argparse.ArgumentParser(description="Floyorker end-to-end merch pipeline")
    p.add_argument("--svg",          required=True, help="Path to SVG design file")
    p.add_argument("--title",        required=True, help="Product title")
    p.add_argument("--product-type", required=True,
                   choices=list(PRODUCT_CATALOG), help="Product type")
    p.add_argument("--price",        required=True, type=float, help="Retail price (USD)")
    p.add_argument("--description",  default="",    help="Product description (HTML OK)")
    args = p.parse_args()

    run_pipeline(
        svg_path=args.svg,
        title=args.title,
        product_type=args.product_type,
        price=args.price,
        description=args.description,
    )


if __name__ == "__main__":
    main()
