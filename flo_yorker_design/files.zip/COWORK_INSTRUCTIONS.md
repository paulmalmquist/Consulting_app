# FLOYORKER MERCH WORKFLOW — COWORK INSTRUCTIONS
# ================================================
# Drop this file in your Floyorker repo root.
# Cowork reads it to know the full pipeline and how to run it.

## WHAT THIS WORKFLOW DOES
When I tell you to push a design, you will:
1. Take an approved SVG file (or convert a PNG using png_to_vector.py first)
2. Run floyorker_pipeline.py to push it through Printful → Shopify → this repo
3. Commit and push the new product JSON to the repo
4. (Optional) Trigger a site rebuild if a deploy hook is configured

---

## DIRECTORY STRUCTURE YOU MANAGE
```
floyorker/
├── data/
│   ├── products/          ← one JSON per product (pipeline writes here)
│   └── products_index.json ← auto-updated index of all products
├── tools/
│   ├── floyorker_pipeline.py   ← main orchestrator
│   ├── png_to_vector.py        ← PNG → SVG converter
│   └── .env                    ← credentials (NEVER commit this)
└── COWORK_INSTRUCTIONS.md      ← this file
```

---

## TRIGGER PHRASES → WHAT TO DO

### "Push this design" / "launch [title]"
```bash
# If input is PNG, convert first:
python tools/png_to_vector.py designs/mydesign.png -o designs/mydesign.svg

# Then run the pipeline:
python tools/floyorker_pipeline.py \
  --svg designs/mydesign.svg \
  --title "My Design Title" \
  --product-type tshirt \
  --price 29.99
```
After the script succeeds:
```bash
git add data/products/ data/products_index.json
git commit -m "Add product: My Design Title"
git push origin main
```

### "Convert this PNG to vector"
```bash
python tools/png_to_vector.py INPUT.png --bg auto --tolerance 30
```
Show me the resulting SVG path so I can approve it before pushing.

### "Show me all products"
Read and display `data/products_index.json` in a readable format.

### "Update product [title]"
Edit the matching JSON in `data/products/`, then git commit + push.

### "Publish [title] on Shopify"
Use the Shopify Admin API to change product status from draft → active:
```bash
curl -X PUT https://$SHOPIFY_STORE/admin/api/2025-07/products/PRODUCT_ID.json \
  -H "X-Shopify-Access-Token: $SHOPIFY_ADMIN_TOKEN" \
  -H "Content-Type: application/json" \
  -d '{"product": {"id": PRODUCT_ID, "status": "active"}}'
```
Load SHOPIFY_STORE and SHOPIFY_ADMIN_TOKEN from tools/.env

---

## PRODUCT TYPES AVAILABLE
| Key       | Product                         | Typical Price |
|-----------|---------------------------------|---------------|
| tshirt    | Bella+Canvas Unisex Tee         | $28–$35       |
| hoodie    | Gildan Heavy Blend Crewneck     | $45–$55       |
| poster    | Enhanced Matte Poster           | $18–$30       |
| sticker   | Kiss-Cut Stickers               | $4–$8         |
| hat       | Yupoong Dad Hat                 | $25–$35       |

---

## ENVIRONMENT SETUP (one time)
```bash
cd tools/
cp .env.example .env
# Fill in .env with your Printful token, Shopify token, etc.
pip install requests python-dotenv Pillow
brew install potrace   # for best SVG vectorization
```

---

## DESIGN APPROVAL FLOW
Designs are approved before pushing. The approval app lives at:
`tools/design_approval.html` — open in browser, drag in a design, click Approve.
Once approved, tell me "push it" and I'll run the pipeline with the approved file.

---

## NEVER DO
- Never commit the `.env` file
- Never push a product to Shopify as `active` without your explicit "publish it" instruction
- Never delete files from `data/products/` without being told
- Always confirm the pipeline succeeded before git pushing
