#!/usr/bin/env python3
"""
PNG → Design-Ready SVG Vector Converter
- Removes background (white, solid color, or auto-detected)
- Traces edges and fills into clean SVG paths
- Outputs transparent-background SVG ready for Figma, Illustrator, etc.

Requirements:
    pip install Pillow numpy scikit-image potrace
    # potrace binary also needed:
    # macOS:  brew install potrace
    # Ubuntu: sudo apt install potrace
    # Windows: download from http://potrace.sourceforge.net/
"""

import argparse
import os
import subprocess
import sys
import tempfile
from pathlib import Path

# ── Optional heavy deps (graceful fallback messages) ──────────────────────────
try:
    import numpy as np
    from PIL import Image
    HAS_PIL = True
except ImportError:
    HAS_PIL = False

try:
    from skimage import measure, morphology
    HAS_SKIMAGE = True
except ImportError:
    HAS_SKIMAGE = False


# ══════════════════════════════════════════════════════════════════════════════
# 1. BACKGROUND REMOVAL
# ══════════════════════════════════════════════════════════════════════════════

def remove_background(img: "Image.Image", mode: str = "auto", tolerance: int = 30) -> "Image.Image":
    """
    Return an RGBA image with the background set to transparent.

    mode:
        'white'   – remove near-white pixels
        'corner'  – sample the top-left corner as the bg colour (works for any solid bg)
        'auto'    – try corner first; fall back to white if corner is very light
    tolerance:  colour distance threshold (0-255)
    """
    img = img.convert("RGBA")
    data = np.array(img, dtype=np.float32)  # H×W×4

    rgb = data[:, :, :3]

    if mode == "white" or (mode == "auto" and _is_light(data[0, 0, :3])):
        bg_color = np.array([255, 255, 255], dtype=np.float32)
    else:
        # sample the four corners and pick the most common colour
        corners = [data[0, 0, :3], data[0, -1, :3], data[-1, 0, :3], data[-1, -1, :3]]
        bg_color = np.mean(corners, axis=0)

    dist = np.linalg.norm(rgb - bg_color, axis=2)   # Euclidean distance per pixel
    mask = dist < tolerance                           # True = background

    # soft anti-alias: pixels near the edge get partial alpha
    alpha_channel = data[:, :, 3].copy()
    alpha_channel[mask] = 0

    # optional: erode 1 px to remove fringe
    if HAS_SKIMAGE:
        fg_mask = ~mask
        fg_mask = morphology.binary_erosion(fg_mask, morphology.disk(1))
        alpha_channel[~fg_mask] = 0

    out = data.copy()
    out[:, :, 3] = alpha_channel
    return Image.fromarray(np.uint8(np.clip(out, 0, 255)), "RGBA")


def _is_light(rgb: "np.ndarray", threshold: int = 200) -> bool:
    return float(np.mean(rgb)) > threshold


# ══════════════════════════════════════════════════════════════════════════════
# 2.  RASTER → BMP (potrace needs BMP or PBM input)
# ══════════════════════════════════════════════════════════════════════════════

def rgba_to_bw_bmp(img_rgba: "Image.Image", tmp_dir: str) -> str:
    """Convert RGBA image to a 1-bit BMP for potrace."""
    gray = img_rgba.convert("L")
    # threshold: foreground = dark pixels
    bw = gray.point(lambda p: 255 if p < 128 else 0, "1")
    bmp_path = os.path.join(tmp_dir, "input.bmp")
    bw.save(bmp_path)
    return bmp_path


# ══════════════════════════════════════════════════════════════════════════════
# 3.  POTRACE TRACING
# ══════════════════════════════════════════════════════════════════════════════

def trace_with_potrace(bmp_path: str, svg_path: str,
                       turd_size: int = 2,
                       corner_threshold: float = 1.0,
                       alpha_max: float = 1.0,
                       opt_tolerance: float = 0.2) -> bool:
    """
    Run potrace to trace the BMP into an SVG.

    Key potrace flags used:
        -b svg            output format
        --turdsize        min area to keep (removes noise)
        --corner          corner threshold (0=smooth, 1.33=sharp)
        --alpha-max       alpha parameter for Bezier fitting
        --opttolerance    curve optimisation tolerance
    """
    cmd = [
        "potrace",
        bmp_path,
        "-b", "svg",
        "-o", svg_path,
        "--turdsize", str(turd_size),
        "--corner", str(corner_threshold),
        "--alpha-max", str(alpha_max),
        "--opttolerance", str(opt_tolerance),
    ]
    result = subprocess.run(cmd, capture_output=True, text=True)
    if result.returncode != 0:
        print(f"[potrace error] {result.stderr.strip()}")
        return False
    return True


# ══════════════════════════════════════════════════════════════════════════════
# 4.  SVG POST-PROCESSING (inject transparency + clean up)
# ══════════════════════════════════════════════════════════════════════════════

def make_svg_transparent(svg_path: str, fill_color: str = "#000000") -> str:
    """
    Read the potrace SVG and:
      • Remove the white rect background potrace adds
      • Set fill colour (default black)
      • Make viewBox preserveAspectRatio='xMidYMid meet'
      • Return the cleaned SVG string
    """
    with open(svg_path, "r", encoding="utf-8") as f:
        svg = f.read()

    import re

    # Remove the background rect potrace inserts (fill:#ffffff or fill:white)
    svg = re.sub(
        r'<rect[^>]*fill[=:\s"\']*(?:#fff(?:fff)?|white)[^>]*/?>',
        "",
        svg,
        flags=re.IGNORECASE,
    )

    # Replace the hardcoded black fill with our chosen colour
    svg = svg.replace('fill="#000000"', f'fill="{fill_color}"')
    svg = svg.replace("fill:#000000", f"fill:{fill_color}")

    # Ensure no background colour on the root <svg> element
    svg = re.sub(r'(<svg[^>]*?)background[^;"\s]*:[^;"\s]*;?', r"\1", svg)

    # Add preserveAspectRatio if missing
    if "preserveAspectRatio" not in svg:
        svg = svg.replace("<svg ", '<svg preserveAspectRatio="xMidYMid meet" ', 1)

    return svg


# ══════════════════════════════════════════════════════════════════════════════
# 5.  FALLBACK: pure-Python path tracer (no potrace binary required)
#     Uses scikit-image contour finding → SVG path
# ══════════════════════════════════════════════════════════════════════════════

def trace_with_skimage(img_rgba: "Image.Image", svg_path: str,
                       fill_color: str = "#000000",
                       simplify_tolerance: float = 1.5) -> bool:
    """
    Lightweight fallback tracer using scikit-image find_contours.
    Produces polygonal paths (no Bezier curves) – good enough for many logos.
    """
    if not HAS_SKIMAGE:
        print("[fallback] scikit-image not installed – cannot trace without potrace.")
        return False

    gray = np.array(img_rgba.convert("L"))
    binary = gray < 128  # foreground = dark

    # Clean up noise
    binary = morphology.remove_small_objects(binary, min_size=50)
    binary = morphology.binary_closing(binary, morphology.disk(2))

    contours = measure.find_contours(binary, 0.5)

    h, w = binary.shape
    paths = []
    for contour in contours:
        # simplify with Ramer-Douglas-Peucker via numpy
        pts = _rdp(contour, epsilon=simplify_tolerance)
        if len(pts) < 3:
            continue
        d = f"M {pts[0][1]:.2f},{pts[0][0]:.2f} "
        d += " ".join(f"L {p[1]:.2f},{p[0]:.2f}" for p in pts[1:])
        d += " Z"
        paths.append(f'<path d="{d}" fill="{fill_color}" fill-rule="evenodd"/>')

    svg = (
        f'<svg xmlns="http://www.w3.org/2000/svg" '
        f'viewBox="0 0 {w} {h}" '
        f'preserveAspectRatio="xMidYMid meet">\n'
        + "\n".join(paths)
        + "\n</svg>"
    )

    with open(svg_path, "w", encoding="utf-8") as f:
        f.write(svg)
    return True


def _rdp(points: "np.ndarray", epsilon: float) -> "np.ndarray":
    """Ramer-Douglas-Peucker simplification."""
    if len(points) < 3:
        return points
    start, end = points[0], points[-1]
    line = end - start
    norm = np.linalg.norm(line)
    if norm == 0:
        dists = np.linalg.norm(points - start, axis=1)
    else:
        dists = np.abs(np.cross(line, start - points) / norm)
    idx = np.argmax(dists)
    if dists[idx] > epsilon:
        left = _rdp(points[: idx + 1], epsilon)
        right = _rdp(points[idx:], epsilon)
        return np.vstack([left[:-1], right])
    return np.array([start, end])


# ══════════════════════════════════════════════════════════════════════════════
# 6.  MAIN PIPELINE
# ══════════════════════════════════════════════════════════════════════════════

def convert(
    input_path: str,
    output_path: str | None = None,
    bg_mode: str = "auto",
    tolerance: int = 30,
    fill_color: str = "#000000",
    turd_size: int = 2,
    corner: float = 1.0,
    alpha_max: float = 1.0,
    opt_tolerance: float = 0.2,
    fallback: bool = True,
) -> str:
    """
    Full pipeline: PNG → background-removed RGBA → SVG vector.
    Returns the path to the output SVG.
    """
    if not HAS_PIL:
        sys.exit("❌  Pillow not installed.  Run: pip install Pillow numpy")

    input_path = Path(input_path)
    if not input_path.exists():
        sys.exit(f"❌  File not found: {input_path}")

    if output_path is None:
        output_path = input_path.with_suffix(".svg")
    output_path = Path(output_path)

    print(f"📂  Input  : {input_path}")
    print(f"📁  Output : {output_path}")

    # Step 1 – load & remove background
    print("🎨  Removing background …")
    img = Image.open(input_path)
    img_rgba = remove_background(img, mode=bg_mode, tolerance=tolerance)

    with tempfile.TemporaryDirectory() as tmp:
        svg_tmp = os.path.join(tmp, "output.svg")

        # Step 2 – try potrace first
        potrace_ok = False
        if _potrace_available():
            print("✏️   Tracing with potrace …")
            bmp_path = rgba_to_bw_bmp(img_rgba, tmp)
            potrace_ok = trace_with_potrace(
                bmp_path, svg_tmp,
                turd_size=turd_size,
                corner_threshold=corner,
                alpha_max=alpha_max,
                opt_tolerance=opt_tolerance,
            )
            if potrace_ok:
                svg_content = make_svg_transparent(svg_tmp, fill_color=fill_color)
                output_path.write_text(svg_content, encoding="utf-8")

        # Step 3 – fallback to skimage tracer
        if not potrace_ok:
            if fallback:
                print("⚠️   potrace not found – using scikit-image fallback tracer …")
                ok = trace_with_skimage(
                    img_rgba, str(output_path),
                    fill_color=fill_color,
                )
                if not ok:
                    sys.exit("❌  Tracing failed. Install potrace or scikit-image.")
            else:
                sys.exit(
                    "❌  potrace not found. Install it:\n"
                    "    macOS:  brew install potrace\n"
                    "    Ubuntu: sudo apt install potrace\n"
                    "    Win:    http://potrace.sourceforge.net/"
                )

    print(f"✅  Done! SVG saved to: {output_path}")
    return str(output_path)


def _potrace_available() -> bool:
    try:
        subprocess.run(["potrace", "--version"], capture_output=True, check=True)
        return True
    except (FileNotFoundError, subprocess.CalledProcessError):
        return False


# ══════════════════════════════════════════════════════════════════════════════
# 7.  CLI
# ══════════════════════════════════════════════════════════════════════════════

def main():
    parser = argparse.ArgumentParser(
        description="Convert PNG → design-ready SVG with transparent background"
    )
    parser.add_argument("input", help="Input PNG file")
    parser.add_argument("-o", "--output", help="Output SVG path (default: same name, .svg)")
    parser.add_argument(
        "--bg", choices=["auto", "white", "corner"], default="auto",
        help="Background removal mode (default: auto)"
    )
    parser.add_argument(
        "--tolerance", type=int, default=30,
        help="Colour tolerance for bg removal (0-255, default: 30)"
    )
    parser.add_argument(
        "--color", default="#000000",
        help="Fill colour for the vector paths (default: #000000)"
    )
    parser.add_argument(
        "--turd", type=int, default=2,
        help="potrace: min island area to keep (default: 2)"
    )
    parser.add_argument(
        "--corner", type=float, default=1.0,
        help="potrace: corner threshold 0=smooth … 1.33=sharp (default: 1.0)"
    )
    parser.add_argument(
        "--alpha-max", type=float, default=1.0,
        help="potrace: Bezier alpha-max (default: 1.0)"
    )
    parser.add_argument(
        "--opt-tolerance", type=float, default=0.2,
        help="potrace: curve optimisation tolerance (default: 0.2)"
    )
    parser.add_argument(
        "--no-fallback", action="store_true",
        help="Fail if potrace is not installed instead of using scikit-image fallback"
    )

    args = parser.parse_args()

    convert(
        input_path=args.input,
        output_path=args.output,
        bg_mode=args.bg,
        tolerance=args.tolerance,
        fill_color=args.color,
        turd_size=args.turd,
        corner=args.corner,
        alpha_max=args.alpha_max,
        opt_tolerance=args.opt_tolerance,
        fallback=not args.no_fallback,
    )


if __name__ == "__main__":
    main()
